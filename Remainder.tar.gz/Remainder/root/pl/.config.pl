#!/usr/bin/perl

use WWW::Mechanize;

return +{
    Email => 'infinith4@gmail.com',
    Passwd => 'pallallp5',
};

