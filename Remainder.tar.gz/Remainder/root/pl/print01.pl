#!/usr/bin/perl

use strict;
use warnings;

my $mail = "remainder.infomation\@gmail.com";

print '"from to" <$mail>'."\n";

